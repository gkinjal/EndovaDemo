//
//  ContentView.swift
//  EndovaDemo
//
//  Created by kinjal.gadhia.ext@bayer.com on 20/12/21.
//  Copyright © 2021 kinjal.gadhia.ext@bayer.com. All rights reserved.
//

import SwiftUI

var istext : String = ""
struct ContentView: View {
    @State private var name: String = ""
    @State private var password: String = ""
    @State private var email: String = ""
    
    let verticalPaddingForForm = 24.0
    var body: some View {
        ZStack {
            VStack(spacing: CGFloat(24.0)) {
                Image("title")
                    .padding(.top, 74.0)
                    .padding(.bottom, 107.0)
                
                
                
                HStack {
                    
                    Image( "user")
                        .resizable()
                        .frame(width: 11.33, height: 11.33)
                        .foregroundColor(.secondary)
                    FloatingTextField(placeholder: "Enter your name", text: $name)
                        .font(Font.custom("Inter-Regular", size: 12))
                    
                    
                }
                
                .padding()
                
                
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(istext.isEmpty ? .gray.opacity(0.5) : .gray.opacity(0.9), lineWidth: 0.5)
                        .background(Color.white)
                        .cornerRadius(8)
                )
                .frame(width: 302.0, height: 52.0, alignment: .center)
                
                
                
                HStack {
                    
                    Image("password")
                        .resizable()
                        .frame(width: 14.17, height: 14.17) .foregroundColor(.secondary)
                    FloatingTextField(placeholder: "Enter password", text: $password)
                        .textContentType(.password)
                        .font(Font.custom("Inter-Regular", size: 12))
                    
                    Image("eye")
                        .resizable()
                        .frame(width: 17.42, height: 11.88) .foregroundColor(.secondary)
                    
                }
                .padding()
                
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(istext.isEmpty ? .gray.opacity(0.5) : .gray.opacity(0.9), lineWidth: 0.5)
                        .background(Color.white)
                        .cornerRadius(8)
                )
                .frame(width: 302.0, height: 52.0, alignment: .center)
                
                HStack {
                    
                    Image("email")
                        .resizable()
                        .frame(width: 14.17, height: 14.17) .foregroundColor(.secondary)
                    FloatingTextField(placeholder: "Enter Email", text: $email)
                        .font(Font.custom("Inter-Regular", size: 12))
                    
                    
                    
                }
                .padding()
                
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(istext.isEmpty ? .gray.opacity(0.5) : .gray.opacity(0.9), lineWidth: 0.5)
                        .background(Color.white)
                        .cornerRadius(8)
                )
                .frame(width: 302.0, height: 52.0, alignment: .center)
                
                HStack {
                    Spacer()
                    Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/) {
                        Text("Forgotten Password ?")
                            .multilineTextAlignment(.trailing)
                            .padding(.trailing, 0)
                            .font(Font.custom("Inter-Regular", size: 15))
                        
                        
                    }
                    
                    .foregroundColor(Color(red: 191/255.0, green: 155/255.0, blue: 155/255.0))
                    
                }.padding(.horizontal,12)
                
                HStack {
                    Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/) {
                        Text("LOGIN")
                    }
                    .padding()
                    .frame(width: 302.0, height: 52.0, alignment: .center)
                    .font(Font.custom("Inter-SemiBold", size: 20))
                    
                    
                    
                    .background(Color(red: 115/255.0, green: 61/255.0, blue: 71/255.0, opacity: 1))
                    .foregroundColor(Color.white)
                    .cornerRadius(12.99)
                    
                }.padding(.leading,12)
                
                HStack(spacing:8){
                    Text("Don't have an Account ?").foregroundColor(Color.gray.opacity(0.5))
                    Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/) {
                        Text("Sign Up ?")
                        
                        
                        
                    }.foregroundColor(Color(red: 191/255.0, green: 155/255.0, blue: 155/255.0))
                }
            }.padding(.horizontal, CGFloat(verticalPaddingForForm))
            
            
            
            
        }
    };
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
struct FloatingTextField: View {
    var placeholder: String
    @Binding var text: String
    var body: some View {
        ZStack(alignment: .leading) {
            
            Text(placeholder)
                .textFiledPlaceholder(text: self.text)
            TextField("", text: $text)
                .font(Font.custom("Inter-Regular", size: 12))
        }
        
        .textFieldShape(text: self.text)
    }
}
extension View {
    func textFieldShape(text: String) -> some View {
        
        self.animation(.easeOut, value: text.isEmpty)
        
            .font(Font.custom("Inter-Regular", size: 12))
            .foregroundColor(Color.black)
        
        
    }
    
    func textFiledPlaceholder(text: String) -> some View {
        self.font(text.isEmpty ? .body : .subheadline)
            .font(Font.custom("Inter-Regular", size: 12))
            .foregroundColor(.gray)
            .padding(.horizontal, text.isEmpty ? 0 : 10)
            .background(Color.white)
            .cornerRadius(5)
            .offset(y: text.isEmpty ? 0 : -23)
            .scaleEffect(text.isEmpty ? 1 : 0.9, anchor: .leading)
    }
}
